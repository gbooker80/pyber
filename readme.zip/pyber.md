
# Pyber Ride Sharing

<h3>Analysis</h3>

-Rural Fares tend to have higher average fares but make up a small proportion of overall revenue.

-Drivers are heavily centered in urban areas and this may have a negative effect on average fares in this area.

-Despite the lower average fares, urban areas account for 63% of total revenue.


```python
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns

city_data = "city_data.csv"
city_data  = pd.read_csv(city_data)
ride_data = "ride_data.csv"
ride_data = pd.read_csv(ride_data)

avg_fare = ride_data.groupby(["city"])["fare"].mean()

avg_fare = pd.DataFrame(avg_fare).rename(columns={"fare": "Average Fare"}).reset_index()
total_rides = ride_data.groupby(["city"])["ride_id"].count()
total_rides = pd.DataFrame(total_rides).rename(columns={"ride_id": "Total Number of Rides"}).reset_index()
driver_count = city_data.groupby(["city", "type"])["driver_count"].sum()
driver_count = pd.DataFrame(driver_count).rename(columns={"driver_count": "Driver Count"}).reset_index()

df1 = pd.merge(total_rides, avg_fare,how="inner",on="city")
df2 = pd.merge(df1, driver_count,how="inner",on=
                         "city").rename(columns={"city": "City","type": "City Type"})

df3=df2[["City", "Average Fare", "Total Number of Rides",  "Driver Count", "City Type"]]

df3['Average Fare']=df3['Average Fare'].map("${:,.2f}".format)

df3.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Average Fare</th>
      <th>Total Number of Rides</th>
      <th>Driver Count</th>
      <th>City Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>$23.93</td>
      <td>31</td>
      <td>21</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>$20.61</td>
      <td>26</td>
      <td>67</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>$37.32</td>
      <td>9</td>
      <td>16</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>$23.62</td>
      <td>22</td>
      <td>21</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>$21.98</td>
      <td>19</td>
      <td>49</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>



<h3>Bubble Plot of Ride Sharing Data</h3>


```python
clrlist = ["lightcoral", "lightskyblue", "gold"]
sns.set_palette(clrlist)

sns.lmplot(x="Total Number of Rides", y="Average Fare", data= df2, 
           hue="City Type",  size=5, aspect=1.5 ,
           legend_out = False, legend = True, 
           scatter_kws={"s":df2["Driver Count"]*15, 
                        'alpha':.55,'edgecolors':"black", 'linewidth':1},ci=0, fit_reg=False, )

plt.legend(loc="upper right", markerscale=.5, title="City Type", fontsize=10, frameon=True)
plt.title("Pyber Ride Sharing Data (2016)", fontsize=18)

plt.show()
```


![png](output_5_0.png)


<h3>Total Fares by City Type</h3>


```python
pie_ct = pd.merge(city_data, ride_data,how="inner",on="city")
pie_ct = pie_ct.groupby(["type"])["fare"].sum()

cities=["Rural","Suburban","Urban"]
colors = ["gold","lightskyblue","lightcoral"]

explode = (0,0,.1)
plt.pie(pie_ct_fare, labels=cities, explode=explode,labeldistance=1.1,
        autopct="%1.1f%%", colors=colors, shadow=True, startangle=110)
plt.axis("equal")
plt.title("Percentage of Total Revenue by City Type", fontsize=12)


plt.show()
```


![png](output_7_0.png)


<h3>Total Rides by City Type</h3>


```python
pie_tr = pd.merge(city_data, ride_data,how="inner",on="city")
pie_tr = pie_tr.groupby(["type"])["ride_id"].count()

explode = (0,0,.1)
plt.pie(pie_tr, labels=cities, explode=explode,labeldistance=1.1,
        autopct="%1.1f%%", colors=colors, shadow=True, startangle=110)
plt.axis("equal")
plt.title("Total Rides by City Type", fontsize=12)

plt.show()
```


![png](output_9_0.png)


<h3>Total Drivers by City Type</h3>


```python
pie_td = pd.merge(city_data, ride_data,how="inner",on="city")
pie_td = pie_td.drop_duplicates(['city'])

pie_td = pie_td.groupby(['type'])['driver_count'].sum()

explode = (0,0,.1)
plt.pie(pie_td, labels=cities, explode=explode,labeldistance=1.1,
        autopct="%1.1f%%", colors=colors, shadow=True, startangle=110)
plt.axis("equal")
plt.title("Total Drivers by City Type", fontsize=12)

plt.show()
```


![png](output_11_0.png)

